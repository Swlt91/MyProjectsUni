To run all 5 examples as an executable, click on the file called "runTests" in the examples folder.

This will run the examples and leave the command prompt open so the output can be viewed.

The examples can also be run via the command prompt.

In the example folder in the command prompt and the below command will run an example:
java -classpath ..\ObjScript/bin ObjScript <  test02.oscript

The last part of the command can be altered to run a different example, eg test02.oscript to test02.oscript etc.

Running examples from the command prompt within the language source folder will need this command:

java -classpath ./bin ObjScript <  test02.oscript

Any created examples can be ran via the command prompt.

They can also be added to the runTests batch file by editing it and adding the same command mentioned above, where only the example name needs to be changed.

The examples that create files will store these files in the examples folder. The examples that read files will be reading files from example folder.