/** Convenient runner for the Sili interpreter. */

public class ObjScript {
	public static void main(String[] args) {
		objScript.interpreter.Interpreter.main(args);
	}
}
