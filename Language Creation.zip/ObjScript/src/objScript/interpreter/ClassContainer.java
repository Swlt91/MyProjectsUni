package objScript.interpreter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import objScript.values.Value;

public class ClassContainer {

	public List<ClassInstance> classes = new ArrayList<ClassInstance>();
	public List<ClassType> classTypes = new ArrayList<ClassType>();

	// define a new class type
	void defineClassType(String name) {
		ClassType newClass = new ClassType(name);
		classTypes.add(newClass);
	}

	// find a class type
	ClassType findClassType(String name) {
		for (int i = 0; i < classTypes.size(); i++) {
			if (Objects.equals(classTypes.get(i).className, name)) {
				return classTypes.get(i);
			}
		}
		return null;
	}

	// find an instance of a class
	ClassInstance findClassInstance(String name) {
		for (int i = 0; i < classes.size(); i++) {
			if (Objects.equals(classes.get(i).name, name)) {
				return classes.get(i);
			}
		}
		return null;
	}

	void SetClass(ClassInstance c) {
		for (int i = 0; i < classes.size(); i++) {
			if (classes.get(i).name.equalsIgnoreCase(c.name)) {
				classes.set(i, c);
			}
		}

	}

	Display.Reference searchVariable(String className, String varName) {
		ClassType c = findClassType(className);
		Display.Reference r;
		return r = c.scope.findReference(varName);

	}

	// define a class instance
	void defineClass(String name, ClassType type) {
		ClassInstance c;
		try {
			c = new ClassInstance(name, type);
			classes.add(c);
		} catch (CloneNotSupportedException e) {

		}
		
	}

	// gets the number of classes existing with a certain class type
	int getNumberOfClassWithName(String name) {
		int counter = 0;

		for (int i = 0; i < classes.size(); i++) {
			if (classes.get(i).classType.className.equalsIgnoreCase(name)) {
				counter++;
			}
		}

		return counter;
	}
}
