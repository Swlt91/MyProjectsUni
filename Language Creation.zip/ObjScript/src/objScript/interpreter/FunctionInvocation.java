package objScript.interpreter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

import objScript.values.Value;

/** Function invocation context. */
class FunctionInvocation {

	private FunctionDefinition function;
	private int argumentCount = 0;
	private Vector<Value> slots;
	public ArrayList<String> names = new ArrayList<String>();
	
	private final void setSlot(int n, Value v) {
		if (n >= slots.size())
			slots.setSize(n + 1);
		slots.set(n, v);
	}
	
	int getArgumentCount()
	{
		return argumentCount;
	}
	
	void setArgumentCount(int inArg)
	{
		argumentCount = inArg;
	}
	
	void copyVector(Vector<Value> inSlots)
	{
		inSlots.addAll(slots);
	}
	
	void setVector(Vector<Value> inSlots)
	{
		slots.addAll(inSlots);
	}
	int VarReferenceCount()
	{
		if(function != null)
		{
		return function.getVarNumber();
		}
		
		return -1;
	}
	int ValueCount()
	{
		return slots.size();
	}
	
	void setFunctionDefFunctions(HashMap<String, FunctionDefinition> inFunctions)
	{
		function.setFunctions(inFunctions);
	}
	
	void copyFunctionsFunctionDef(HashMap<String, FunctionDefinition> inFunctions)
	{
		function.copyFunctions(inFunctions);
	}
	
	void setFunctionDefHash(HashMap<String, Integer> inSlots)
	{
		function.setSlots(inSlots);
	}
	
	void copySlotsFunctionDef(HashMap<String, Integer> inSlots)
	{
		function.copySlots(inSlots);
	}
	/** Ctor for user-defined function. */
	FunctionInvocation(FunctionDefinition fndef) {
		function = fndef;
		slots = new Vector<Value>(function.getLocalCount());
	}
	
	/** Get the level of the associated function. */
	int getLevel() {
		return function.getLevel();
	}
	
	void setArgumentFromArgList(Value v, int index)
	{
		if (index >= function.getParameterCount())
			throw new ExceptionSemantic("Function " + function.getSignature() + " expected " + function.getParameterCount() + " arguments but got " + (argumentCount + 1) + ".");
		// First slots are always arguments
		//function.setParameter(index, v);
		//setSlot(index, v);
	}
	/** Set an argument value. */
	void setArgument(Value v, String s) {
		if (argumentCount >= function.getParameterCount())
			throw new ExceptionSemantic("Function " + function.getSignature() + " expected " + function.getParameterCount() + " arguments but got " + (argumentCount + 1) + ".");
		// First slots are always arguments
		names.add(s);
		setSlot(argumentCount++, v);
	}
	
	/** Check argument count. */
	void checkArgumentCount() {
		if (argumentCount < function.getParameterCount())
			throw new ExceptionSemantic("Function " + function.getSignature() + " expected " + function.getParameterCount() + " arguments but got " + (argumentCount + 1) + ".");		
	}
	
	/** Execute this invocation. */
	Value execute(Parser parser) {
		parser.doChildren(function.getFunctionBody(), null);
		if (function.hasReturn())
		{
			return parser.doChild(function.getFunctionReturnExpression(), 0);
		}
		return null;
	}

	/** Get the slot number of a given variable or parameter name.  Return -1 if not found. */
	int findSlotNumber(String name) {
		
		return function.getLocalSlotNumber(name);
	}
	

	/** Get a variable or parameter value given a slot number. */
	Value getValue(int slotNumber) {
		return slots.get(slotNumber);
	}

	/** Given a slot number, set its value. */
	void setValue(int slotNumber, Value value) {
		setSlot(slotNumber, value);
	}

	/** Define a variable in the function definition.  Return its slot number. */
	int defineVariable(String name) {
		return function.defineVariable(name);
	}
	
	void removeVariable(String name)
	{
		function.removeVariable(name);
	}
	/** Add a function definition. */
	void addFunction(FunctionDefinition definition) {
		function.addFunction(definition);
	}
	
	/** Find a function definition.  Return null if it doesn't exist. */
	FunctionDefinition findFunction(String name) {
		return function.findFunction(name);
	}
	
}
