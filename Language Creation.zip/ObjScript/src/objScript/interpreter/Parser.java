package objScript.interpreter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import objScript.parser.ast.*;
import objScript.values.*;

public class Parser implements ObjScriptVisitor {

	// Scope display handler
	private Display scope = new Display();

	// object container
	public ClassContainer classContainer = new ClassContainer();
	boolean classCreation = false;
	String className;
	String varName;
	boolean forLoop = false;
	Random random = new Random();

	// Get the ith child of a given node.
	private static SimpleNode getChild(SimpleNode node, int childIndex) {
		return (SimpleNode) node.jjtGetChild(childIndex);
	}

	// Get the token value of the ith child of a given node.
	private static String getTokenOfChild(SimpleNode node, int childIndex) {
		return getChild(node, childIndex).tokenValue;
	}

	// Execute a given child of the given node
	private Object doChild(SimpleNode node, int childIndex, Object data) {
		return node.jjtGetChild(childIndex).jjtAccept(this, data);
	}

	// Execute a given child of a given node, and return its value as a Value.
	// This is used by the expression evaluation nodes.
	Value doChild(SimpleNode node, int childIndex) {
		return (Value) doChild(node, childIndex, null);
	}

	// Execute all children of the given node
	Object doChildren(SimpleNode node, Object data) {
		return node.childrenAccept(this, data);
	}

	// Called if one of the following methods is missing...
	public Object visit(SimpleNode node, Object data) {
		System.out.println(node + ": acceptor not implemented in subclass?");
		return data;
	}

	// Execute a Sili program
	public Object visit(ASTCode node, Object data) {
		return doChildren(node, data);
	}

	// Execute a statement
	public Object visit(ASTStatement node, Object data) {
		return doChildren(node, data);
	}

	// Execute a block
	public Object visit(ASTBlock node, Object data) {
		return doChildren(node, data);
	}

	// Function definition
	public Object visit(ASTFnDef node, Object data) {
		// Already defined?
		if (node.optimised != null)
			return data;
		// Child 0 - identifier (fn name)
		String fnname = getTokenOfChild(node, 0);

		if (scope.findFunctionInCurrentLevel(fnname) != null)
			throw new ExceptionSemantic("Function " + fnname + " already exists.");
		FunctionDefinition currentFunctionDefinition = new FunctionDefinition(fnname, scope.getLevel() + 1);
		// Child 1 - function definition parameter list

		doChild(node, 1, currentFunctionDefinition);
		// Add to available functions
		scope.addFunction(currentFunctionDefinition);
		// Child 2 - function body
		currentFunctionDefinition.setFunctionBody(getChild(node, 2));
		// Child 3 - optional return expression
		if (node.fnHasReturn)
			currentFunctionDefinition.setFunctionReturnExpression(getChild(node, 3));
		// Preserve this definition for future reference, and so we don't define
		// it every time this node is processed.
		node.optimised = currentFunctionDefinition;
		return data;

	}

	// Function definition parameter list
	public Object visit(ASTParmlist node, Object data) {
		FunctionDefinition currentDefinition = (FunctionDefinition) data;
		for (int i = 0; i < node.jjtGetNumChildren(); i++)
			currentDefinition.defineParameter(getTokenOfChild(node, i));
		return data;
	}

	// Function body
	public Object visit(ASTFnBody node, Object data) {
		return doChildren(node, data);
	}

	// Function return expression
	public Object visit(ASTReturnExpression node, Object data) {
		return doChildren(node, data);
	}

	// Function call
	public Object visit(ASTCall node, Object data) {
		FunctionDefinition fndef;

		if (node.optimised == null) {
			// Child 0 - identifier (fn name)
			String fnname = getTokenOfChild(node, 0);
			System.out.println("THENAME:" + fnname);
			fndef = scope.findFunction(fnname);
			if (fndef == null)
				throw new ExceptionSemantic("Function " + fnname + " is undefined.");
			// Save it for next time
			node.optimised = fndef;
		} else
			fndef = (FunctionDefinition) node.optimised;
		FunctionInvocation newInvocation = new FunctionInvocation(fndef);

		// Child 1 - arglist
		doChild(node, 1, newInvocation);

		// Execute
		scope.execute(newInvocation, this);

		// find the references and change the value
		for (int i = 0; i < newInvocation.names.size(); i++) {
			Display.Reference reference;
			reference = scope.findReference(newInvocation.names.get(i));
			if (reference == null) {
				ClassInstance c = classContainer.findClassInstance(className);
				reference = c.scope.findReference(newInvocation.names.get(i));
			}
			reference.setValue(newInvocation.getValue(i));
		}

		return data;
	}

	// Function invocation in an expression
	public Object visit(ASTFnInvoke node, Object data) {
		FunctionDefinition fndef;

		if (node.optimised == null) {
			// Child 0 - identifier (fn name)
			String fnname = getTokenOfChild(node, 0);
			fndef = scope.findFunction(fnname);
			if (fndef == null)
				throw new ExceptionSemantic("Function " + fnname + " is undefined.");
			if (!fndef.hasReturn())
				throw new ExceptionSemantic(
						"Function " + fnname + " is being invoked in an expression but does not have a return value.");
			// Save it for next time
			node.optimised = fndef;
		} else
			fndef = (FunctionDefinition) node.optimised;
		FunctionInvocation newInvocation = new FunctionInvocation(fndef);
		// Child 1 - arglist
		doChild(node, 1, newInvocation);
		// Execute
		return scope.execute(newInvocation, this);
	}

	// Function invocation argument list.
	public Object visit(ASTArgList node, Object data) {
		FunctionInvocation newInvocation = (FunctionInvocation) data;
		// newInvocation.
		for (int i = 0; i < node.jjtGetNumChildren(); i++) {
			String name = getTokenOfChild(node, i);
			if (name == null) {
				name = varName;
			}

			newInvocation.setArgument(doChild(node, i), varName);
			// newInvocation.setArgumentFromArgList(doChild(node, i), i);
		}
		newInvocation.checkArgumentCount();
		return data;
	}

	// Execute an IF
	public Object visit(ASTIfStatement node, Object data) {
		// evaluate boolean expression
		Value hopefullyValueBoolean = doChild(node, 0);
		if (!(hopefullyValueBoolean instanceof ValueBoolean))
			throw new ExceptionSemantic("The test expression of an if statement must be boolean.");
		if (((ValueBoolean) hopefullyValueBoolean).booleanValue())
			doChild(node, 1); // if(true), therefore do 'if' statement
		else if (node.ifHasElse) // does it have an else statement?
			doChild(node, 2); // if(false), therefore do 'else' statement
		return data;
	}

	// Execute a FOR loop
	public Object visit(ASTForLoop node, Object data) {
		// loop initialisation
		forLoop = true;
		doChild(node, 0);
		while (true) {
			// evaluate loop test
			Value hopefullyValueBoolean = doChild(node, 1);
			if (!(hopefullyValueBoolean instanceof ValueBoolean))
				throw new ExceptionSemantic("The test expression of a for loop must be boolean.");
			if (!((ValueBoolean) hopefullyValueBoolean).booleanValue())
				break;
			// do loop statement
			doChild(node, 3);
			// assign loop increment
			doChild(node, 2);
		}

		forLoop = false;
		scope.removeVariable(varName);
		return data;
	}

	// Process an identifier
	// This doesn't do anything, but needs to be here because we need an
	// ASTIdentifier node.
	public Object visit(ASTIdentifier node, Object data) {
		return data;
	}

	// Execute the WRITE statement
	public Object visit(ASTWrite node, Object data) {
		System.out.println(doChild(node, 0));
		return data;
	}

	// Dereference a variable or parameter, and return its value.
	public Object visit(ASTDereference node, Object data) {
		Display.Reference reference;
		if (node.optimised == null) {
			String name = node.tokenValue;
			reference = scope.findReference(name);
			if (reference == null) {
				ClassInstance c = classContainer.findClassInstance(name);

				if (c != null) {
					return c.getClass();
				}
				throw new ExceptionSemantic("Variable or parameter " + name + " is undefined.");
			}
			node.optimised = reference;
		} else
			reference = (Display.Reference) node.optimised;
		return reference.getValue();
	}

	// Execute an assignment statement.
	public Object visit(ASTAssignment node, Object data) {
		Display.Reference reference;

		if (node.optimised == null) {
			String name = getTokenOfChild(node, 0);
			// System.out.println(name);
			reference = scope.findReference(name);
			if (reference == null) {
				throw new ExceptionSemantic("Variable or parameter " + name + " has not been instantiated.");
			}
		} else
			reference = (Display.Reference) node.optimised;
		reference.setValue(doChild(node, 1));
		return data;
	}

	// OR
	public Object visit(ASTOr node, Object data) {
		return doChild(node, 0).or(doChild(node, 1));
	}

	// AND
	public Object visit(ASTAnd node, Object data) {
		return doChild(node, 0).and(doChild(node, 1));
	}

	// ==
	public Object visit(ASTCompEqual node, Object data) {
		return doChild(node, 0).eq(doChild(node, 1));
	}

	// !=
	public Object visit(ASTCompNequal node, Object data) {
		return doChild(node, 0).neq(doChild(node, 1));
	}

	// >=
	public Object visit(ASTCompGTE node, Object data) {
		return doChild(node, 0).gte(doChild(node, 1));
	}

	// <=
	public Object visit(ASTCompLTE node, Object data) {
		return doChild(node, 0).lte(doChild(node, 1));
	}

	// >
	public Object visit(ASTCompGT node, Object data) {
		return doChild(node, 0).gt(doChild(node, 1));
	}

	// <
	public Object visit(ASTCompLT node, Object data) {
		return doChild(node, 0).lt(doChild(node, 1));
	}

	// +
	public Object visit(ASTAdd node, Object data) {
		return doChild(node, 0).add(doChild(node, 1));
	}

	// -
	public Object visit(ASTSubtract node, Object data) {
		return doChild(node, 0).subtract(doChild(node, 1));
	}

	// *
	public Object visit(ASTTimes node, Object data) {
		return doChild(node, 0).mult(doChild(node, 1));
	}

	// /
	public Object visit(ASTDivide node, Object data) {
		return doChild(node, 0).div(doChild(node, 1));
	}

	// NOT
	public Object visit(ASTUnaryNot node, Object data) {
		return doChild(node, 0).not();
	}

	// + (unary)
	public Object visit(ASTUnaryPlus node, Object data) {
		return doChild(node, 0).unary_plus();
	}

	// - (unary)
	public Object visit(ASTUnaryMinus node, Object data) {
		return doChild(node, 0).unary_minus();
	}

	// Return string literal
	public Object visit(ASTCharacter node, Object data) {
		if (node.optimised == null)
			node.optimised = ValueString.stripDelimited(node.tokenValue);
		return node.optimised;
	}

	// Return integer literal
	public Object visit(ASTInteger node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueInteger(Long.parseLong(node.tokenValue));
		return node.optimised;
	}

	// Return floating point literal
	public Object visit(ASTRational node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueRational(Double.parseDouble(node.tokenValue));
		return node.optimised;
	}

	// Return true literal
	public Object visit(ASTTrue node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueBoolean(true);
		return node.optimised;
	}

	// Return false literal
	public Object visit(ASTFalse node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueBoolean(false);
		return node.optimised;
	}

	// quit the program
	public Object visit(ASTQuit node, Object data) {
		System.exit(0);
		return null;
	}

	// while loop
	public Object visit(ASTWhileLoop node, Object data) {
		// loop initialisation
		// doChild(node, 0);
		while (true) {
			// evaluate loop test
			Value hopefullyValueBoolean = doChild(node, 0);
			if (!(hopefullyValueBoolean instanceof ValueBoolean))
				throw new ExceptionSemantic("The test expression of a while loop must be boolean.");
			if (!((ValueBoolean) hopefullyValueBoolean).booleanValue())
				break;
			// do loop statement
			doChild(node, 1);
		}
		return data;
	}

	// increment value
	public Object visit(ASTIncrementValue node, Object data) {
		Display.Reference reference;
		if (node.optimised == null) {

			// find the reference
			String name = getTokenOfChild(node, 0);
			reference = scope.findReference(name);

			if (reference == null) {
				throw new ExceptionSemantic("Variable or parameter " + name + " has not been instantiated.");
			}
		} else {

			reference = (Display.Reference) node.optimised;
		}

		// get the value, increment it and then set it
		Value number = reference.getValue();
		number = number.incrementValue();
		reference.setValue(number);
		return data;
	}

	// create variable
	public Object visit(ASTCreateVar node, Object data) {
		Display.Reference reference;
		
		//if a class is being created
		if (classCreation) {
			
			//find the class
			ClassType c = classContainer.findClassType(className);
			if (node.optimised == null) {
				String name = getTokenOfChild(node, 0);

				//find the reference
				reference = c.scope.findReference(name);
				if (reference == null) {
					// if null then create it
					reference = c.scope.defineVariable(name);
					c.addNames(name);
				}

				else {
					throw new ExceptionSemantic("The variable " + name + " already exists");
				}

				node.optimised = reference;
			} else
				throw new ExceptionSemantic("The variable already exists");

			// array
			if (node.jjtGetNumChildren() > 1) {
				reference.setValue(doChild(node, 1));
			}
		}

		// else normal variable creation
		else {
			if (node.optimised == null) {
				String name = getTokenOfChild(node, 0);
				reference = scope.findReference(name);
				if (reference == null) {
					reference = scope.defineVariable(name);
				}

				else {
					throw new ExceptionSemantic("The variable " + name + " already exists");
				}

				node.optimised = reference;
			} else
				throw new ExceptionSemantic("The variable already exists");

			if (node.jjtGetNumChildren() > 1) {
				reference.setValue(doChild(node, 1));
			}
		}

		//used for for loop variables
		if (forLoop) {
			varName = getTokenOfChild(node, 0);
		}
		return data;
	}

	// decrement a value
	public Object visit(ASTDecrementValue node, Object data) {
		Display.Reference reference;
		if (node.optimised == null) {
			String name = getTokenOfChild(node, 0);
			reference = scope.findReference(name);

			if (reference == null) {
				throw new ExceptionSemantic("Variable or parameter " + name + " has not been instantiated.");
			}
		} else {
			reference = (Display.Reference) node.optimised;
		}
		
		//get the value, decrement it and set it
		Value number = reference.getValue();
		number = number.decrementValue();
		reference.setValue(number);
		return data;
	}

	// create an array
	public Object visit(ASTArrayCreate node, Object data) {

		String name = getTokenOfChild(node, 0);
		
		// if a class is being created
		if (classCreation) {
			// find the class
			ClassType c = classContainer.findClassType(className);
			if (c == null) {
				throw new ExceptionSemantic("Object instance " + name + " does not exist.");
			}
			
			// define the array
			int slot = c.scope.arrayContainer.defineArray(name);
			int amount = node.jjtGetNumChildren();
			int i = 1;

			// get each value from the array creation and set it
			Value v[] = new Value[amount - 1];
			while (i < amount) {
				v[i - 1] = doChild(node, i);
				i++;
			}

			// set the array
			c.scope.arrayContainer.setSlot(slot, v);
			return data;
		}

		// else normal array creation
		else {
			//define the array
			int slot = scope.arrayContainer.defineArray(name);
			int amount = node.jjtGetNumChildren();
			int i = 1;

			// set each value 
			Value v[] = new Value[amount - 1];
			while (i < amount) {
				v[i - 1] = doChild(node, i);
				i++;
			}

			// set the array;
			scope.arrayContainer.setSlot(slot, v);
			return data;
		}

	}

	// reference to an array
	public Object visit(ASTDereferenceArray node, Object data) {
		//find the array
		String name = node.tokenValue;
		int slot = scope.arrayContainer.findLocalSlotNumber(name);

		if (slot == -1) {
			throw new ExceptionSemantic("Array " + name + " does not exist.");
		}

		// get the array value by index
		Value v = scope.arrayContainer.getArrayValue(slot, (int) doChild(node, 0).longValue());

		if (v == null) {
			throw new ExceptionSemantic("Index " + doChild(node, 0) + " for Array " + name + " out of bounds.");
		}

		return v;
	}

	// assign a value to the array
	public Object visit(ASTArrayAssignment node, Object data) {

		// find the array
		String name = getTokenOfChild(node, 0);
		int slot = scope.arrayContainer.findLocalSlotNumber(name);

		if (slot == -1) {
			throw new ExceptionSemantic("Array " + name + " does not exist.");
		}

		// set an array value via index
		int i = scope.arrayContainer.setArrayValue(slot, (int) doChild(node, 1).longValue(), doChild(node, 2));

		if (i > 0) {
			throw new ExceptionSemantic("Index " + doChild(node, 0) + " for Array " + name + " out of bounds.");
		}

		return data;
	}

	// create a list
	public Object visit(ASTListCreate node, Object data) {

		// get the list name and check if class is being created
		String name = getTokenOfChild(node, 0);
		if (classCreation) {
			ClassType c = classContainer.findClassType(className);
			if (c == null) {
				throw new ExceptionSemantic("Object instance " + name + " does not exist.");
			}

			// define the list within the class
			int slot = c.scope.listContainer.defineList(name);

			return data;
		}

		// else normal list creation
		else {
			// define the list
			int slot = scope.listContainer.defineList(name);
			return data;
		}

	}


	public Object visit(ASTCreateObject node, Object data) {
		ClassType c;
		if (node.optimised == null) {
			
			//check to see the object has a unique name
			String name = getTokenOfChild(node, 0);
			c = classContainer.findClassType(name);
			if (c == null) {
				classContainer.defineClassType(name);
			}

			else {
				throw new ExceptionSemantic("The Object " + name + " already exists");
			}

		} else
			throw new ExceptionSemantic("The object already exists");

		//set class creation to true for object creation
		node.optimised = classContainer;
		classCreation = true;
		className = getTokenOfChild(node, 0);
		
		//do object body
		doChild(node, 1);
		return data;
	}

	public Object visit(ASTObjectBody node, Object data) {
		//get the variables, lists, object lists and arrays
		doChildren(node, data);
		
		// object creation completed
		classCreation = false;
		return data;
	}

	// references to object variables
	public Object visit(ASTObjectReferences node, Object data) {
		
		// check if the object exists
		String name = getTokenOfChild(node, 1);
		String classNameHere = getTokenOfChild(node, 0);
		ClassInstance c = classContainer.findClassInstance(classNameHere);
		Display.Reference reference = null;
		
		if(c == null)
		{
			throw new ExceptionSemantic("Object instance " + name + " does not exist.");
		}

		if (node.optimised == null) {
			// if array
			if (node.jjtGetNumChildren() == 3) {

				// find the array within the class
				int slot = c.scope.arrayContainer.findLocalSlotNumber(getTokenOfChild(node, 1));

				if (slot == -1) {
					throw new ExceptionSemantic("Array " + name + " does not exist.");
				}

				// get the value at the specified index
				Value v = c.scope.arrayContainer.getArrayValue(slot, (int) doChild(node, 2).longValue());

				if (v == null) {
					throw new ExceptionSemantic("Index " + doChild(node, 2) + " for Array " + name + " out of bounds.");
				}

				return v;
			}

			// else not an array
			else {

				// find the reference to the variable
				reference = c.scope.findReference(name);

				if (reference == null) {
					throw new ExceptionSemantic("Variable or parameter " + name + " is undefined.");
				}

				node.optimised = reference;
			}

		} else
			reference = (Display.Reference) node.optimised;
		//return the value
		className = classNameHere;
		varName = name;
		return reference.getValue();
	}

	// check the object type exists
	public Object visit(ASTObjectType node, Object data) {
		String name = node.tokenValue;
		ClassType c;
		
		// check if the object type exists
		c = classContainer.findClassType(name);
		if (c == null) {
			throw new ExceptionSemantic("Object type " + name + " is not defined");
		}
		return data;

	}

	public Object visit(ASTObjectInstantiate node, Object data) {

		// check class type exists
		doChild(node, 0);
		String name;
		ClassInstance c;
		if (node.optimised == null) {
			name = getTokenOfChild(node, 1);

			// check if the object name is already taken
			c = classContainer.findClassInstance(name);
			if (c == null) {
				ClassType type = classContainer.findClassType(getTokenOfChild(node, 0));
				classContainer.defineClass(name, type);

			}

			else {
				throw new ExceptionSemantic("The object instance " + name + " already exists");
			}

		} else
			throw new ExceptionSemantic("The object already exists");

		node.optimised = classContainer;
		doChild(node, 1);
		className = name;

		// if variables have been passed into the constructor, get them and assign them to the object
		for (int i = 1; i < node.jjtGetNumChildren(); i++) {
			doChild(node, i);
		}
		return data;
	}

	public Object visit(ASTObjectConstructor node, Object data) {

		// check if any variables or arguments exist
		if (node.jjtGetNumChildren() > 0) {
			String name = getTokenOfChild(node, 1);

			// find the object instance
			ClassInstance c = classContainer.findClassInstance(className);

			if (c == null) {

				ClassType type = classContainer.findClassType(getTokenOfChild(node, 0));
				classContainer.defineClass(name, type);
			}

			// get each value and assign it to a object variable
			for (int i = 0; i < node.jjtGetNumChildren(); i++) {

				String nameToCheck = c.classType.getNames(i);

				// iterate through the classes variables names
				//if the variable name is null, too many variables have been passed in the constructor
				if (nameToCheck == null) {
					throw new ExceptionSemantic(
							"Object instance " + className + " does not contain " + i + 1 + " variables");
				}

				Display.Reference reference = c.scope.findReference(nameToCheck);

				// if the reference does not exist, too many variables exist
				if (reference == null) {
					throw new ExceptionSemantic(
							"Object instance " + className + " does not contain " + i + 1 + " variables");
				}
				
				// set the value
				reference.setValue(doChild(node, i));
			}
			return data;
		}

		return data;
	}

	// assignments for variables inside objects
	public Object visit(ASTObjectAssignment node, Object data) {
		Display.Reference reference;
		doChild(node, 0);
		
		// check the object exists 
		if (node.optimised == null) {
			String name = getTokenOfChild(node, 0);
			// System.out.println(getTokenOfChild(node, 2));
			ClassInstance c = classContainer.findClassInstance(name);

			if (c == null) {
				throw new ExceptionSemantic("Object instance " + name + " does not exist.");
			}

			// check the variable name exists within the object
			String varName = getTokenOfChild(node, 1);
			reference = c.scope.findReference(varName);
			if (reference == null) {
				throw new ExceptionSemantic("Variable or parameter " + varName + " has not been instantiated.");
			}
		} else
			reference = (Display.Reference) node.optimised;
		
		// set the value from the result of the expression
		reference.setValue(doChild(node, 2));
		return data;
	}

	// increment a value existing within an object
	public Object visit(ASTObjectIncrementValue node, Object data) {
		Display.Reference reference;
		
		// check the object exists
		if (node.optimised == null) {
			String name = getTokenOfChild(node, 0);
			ClassInstance c = classContainer.findClassInstance(name);

			if (c == null) {
				throw new ExceptionSemantic("Object instance " + name + " does not exist.");
			}
			
			// check the variable exists within the object
			reference = c.scope.findReference(getTokenOfChild(node, 1));

			if (reference == null) {
				throw new ExceptionSemantic("Variable or parameter " + name + " has not been instantiated.");
			}
		} else

			reference = (Display.Reference) node.optimised;

		// apply the increment
		Value number = reference.getValue();
		number = number.incrementValue();
		reference.setValue(number);
		return data;
	}

	// decrement a value existing within an object
	public Object visit(ASTObjectDecrementValue node, Object data) {
		Display.Reference reference;
		
		// check the object instance exists
		if (node.optimised == null) {
			String name = getTokenOfChild(node, 0);
			ClassInstance c = classContainer.findClassInstance(name);

			if (c == null) {
				throw new ExceptionSemantic("Object instance " + name + " does not exist.");
			}

			// check the variable exists within the object
			reference = c.scope.findReference(getTokenOfChild(node, 1));

			if (reference == null) {
				throw new ExceptionSemantic("Variable or parameter " + name + " has not been instantiated.");
			}
		} else

			reference = (Display.Reference) node.optimised;

		// apply the decrement
		Value number = reference.getValue();
		number = number.decrementValue();
		reference.setValue(number);
		return data;
	}

	// apply a new value to an array in an object
	public Object visit(ASTObjectArrayAssignment node, Object data) {
		String name = getTokenOfChild(node, 0);

		// check the object exits
		ClassInstance c = classContainer.findClassInstance(name);

		if (c == null) {
			throw new ExceptionSemantic("Object instance " + name + " does not exist.");
		}

		// find the array
		String arrayName = getTokenOfChild(node, 1);
		int slot = c.scope.arrayContainer.findLocalSlotNumber(arrayName);

		if (slot == -1) {
			throw new ExceptionSemantic("Array " + arrayName + " does not exist.");
		}

		// set the value
		int i = c.scope.arrayContainer.setArrayValue(slot, (int) doChild(node, 2).longValue(), doChild(node, 3));

		if (i > 0) {
			throw new ExceptionSemantic("Index " + doChild(node, 1) + " for Array " + arrayName + " out of bounds.");
		}

		return data;
	}

	// add to a list
	public Object visit(ASTListAdd node, Object data) {

		String name = getTokenOfChild(node, 0);
		boolean objectList = false;

		// check if the list exists
		int slot = scope.listContainer.findLocalSlotNumber(name);

		if (slot == -1) {
			
			// if it does not exist, check if an object list exists
			slot = scope.listContainer.findLocalSlotNumberObject(name);
			objectList = true;

			// no list was found
			if (slot == -1) {
				throw new ExceptionSemantic("list " + name + " does not exist.");
			}
		}

		// check if the command contains a object instance
		String inName = getTokenOfChild(node, 1);
		
		if(inName == null)
		{
			
			inName = doChild(node, 1).stringValue();
		}
		ClassInstance c = classContainer.findClassInstance(inName);
		int i;

		// no object instance found, this is a normal list add command
		if (c == null) {
			// add the value to the list
			i = scope.listContainer.addToList(slot, doChild(node, 1));

		}

		else {

			// object instance found, this is a object list add command, add the object
			i = scope.listContainer.addToListObj(slot, c);
		}

		if (i < 0) {
			throw new ExceptionSemantic("Index " + doChild(node, 0) + " for list " + name + " out of bounds.");
		}

		return data;
	}

	// reference to a list
	public Object visit(ASTDereferenceList node, Object data) {
		String name = getTokenOfChild(node, 0);
		boolean objectList = false;
		
		// check if the reference is for a list or object list
		int slot = scope.listContainer.findLocalSlotNumber(name);

		if (slot == -1) {
			slot = scope.listContainer.findLocalSlotNumberObject(name);

			objectList = true;
			if (slot == -1) {
				throw new ExceptionSemantic("list " + name + " does not exist.");

			}
		}

		// object list found
		if (objectList) {
			// get the object from the object list at the specified index
			ClassInstance c = scope.listContainer.getListObj(slot, (int) doChild(node, 1).longValue());
			return c;
		}

		else {
			// normal list found, get the value from the list at the specified index
			Value ob = scope.listContainer.getListValue(slot, (int) doChild(node, 1).longValue());
			if (ob == null) {
				throw new ExceptionSemantic("Index " + doChild(node, 0) + " for list " + name + " out of bounds.");
			}

			return ob;
		}
	}

	// add to a list existing within an object
	public Object visit(ASTObjectListAdd node, Object data) {
		String name = getTokenOfChild(node, 0);
		
		// find the object
		ClassInstance c = classContainer.findClassInstance(name);

		if (c == null) {
			throw new ExceptionSemantic("Object instance " + name + " does not exist.");
		}

		// find the list
		String listName = getTokenOfChild(node, 1);
		int slot = c.scope.listContainer.findLocalSlotNumber(listName);

		// if the reference is not a list, check the object lists
		if (slot == -1) {
			slot = c.scope.listContainer.findLocalSlotNumberObject(listName);

			// no list fond
			if (slot == -1) {
				throw new ExceptionSemantic("list " + listName + " does not exist.");
			}
		}

		// get the reference to the object to be added and check the object exists, if it exists
		ClassInstance classToAdd = classContainer.findClassInstance(getTokenOfChild(node, 2));
		int i;

		// object reference does not exist, so this is normal list add
		if (classToAdd == null) {
			i = c.scope.listContainer.addToList(slot, doChild(node, 2));
		}

		// object exists, add this to the object list within the specified object
		else {
			i = c.scope.listContainer.addToListObj(slot, classToAdd);
		}

		if (i < 0) {
			throw new ExceptionSemantic("Index " + doChild(node, 1) + " for list " + name + " out of bounds.");
		}

		return data;
	}

	// remove from a list at a specified index
	public Object visit(ASTListRemove node, Object data) {
		String name = getTokenOfChild(node, 0);
		
		// check to see if the list is a normal list or an object list, or if it exists at all
		boolean objectList = false;
		int slot = scope.listContainer.findLocalSlotNumber(name);

		if (slot == -1) {
			slot = scope.listContainer.findLocalSlotNumberObject(name);
			objectList = true;

			if (slot == -1) {
				throw new ExceptionSemantic("list " + name + " does not exist.");
			}
		}

		int i = -1;

		// remove the object from the object list by index
		if (objectList) {
			i = scope.listContainer.removeFromListObj(slot, (int) doChild(node, 1).longValue());
		}

		// remove the normal value from the normal list by index
		else {
			i = scope.listContainer.removeFromList(slot, (int) doChild(node, 1).longValue());
		}

		if (i < 0) {
			throw new ExceptionSemantic("Could not remove from list " + name);
		}

		return data;
	}

	// remove from an list existing within an object
	public Object visit(ASTObjectListRemove node, Object data) {
		String name = getTokenOfChild(node, 0);

		// check if the object exists
		ClassInstance c = classContainer.findClassInstance(name);

		if (c == null) {
			throw new ExceptionSemantic("Object instance " + name + " does not exist");
		}

		boolean objectList = false;
		int slot = scope.listContainer.findLocalSlotNumber(name);

		// check if the list reference is to a normal list or an object list
		if (slot == -1) {
			slot = scope.listContainer.findLocalSlotNumberObject(name);
			objectList = true;

			if (slot == -1) {
				throw new ExceptionSemantic("list " + name + " does not exist.");
			}
		}

		int i = -1;

		// remove the object from the list at the specified index
		if (objectList) {
			i = c.scope.listContainer.removeFromListObj(slot, (int) doChild(node, 1).longValue());
		}

		// remove the value from the list at the specified index
		else {
			i = c.scope.listContainer.removeFromList(slot, (int) doChild(node, 1).longValue());
		}

		if (i < 0) {
			throw new ExceptionSemantic("Could not remove from list " + name);
		}

		return data;
	}

	// get the size value of a list
	public Object visit(ASTDereferenceListCount node, Object data) {
		String name = node.tokenValue;

		// check if the list is a object or normal list and if it exists at all
		boolean objectList = false;
		int slot = scope.listContainer.findLocalSlotNumber(name);

		if (slot == -1) {
			slot = scope.listContainer.findLocalSlotNumberObject(name);
			objectList = true;

			if (slot == -1) {
				throw new ExceptionSemantic("list " + name + " does not exist.");
			}
		}

		Value v;

		// if an object list was found, find its size
		if (objectList) {
			v = new ValueInteger(scope.listContainer.getSizeObject(slot));
		}

		// else it is a normal list, find the size
		else {
			v = new ValueInteger(scope.listContainer.getSize(slot));
		}

		return v;
	}

	// create an object list
	public Object visit(ASTObjListCreate node, Object data) {
		String name = getTokenOfChild(node, 0);
		
		// if the object list is within an object defintion body
		if (classCreation) {
			ClassType c = classContainer.findClassType(className);
			if (c == null) {
				throw new ExceptionSemantic("Object instance " + name + " does not exist.");
			}
			// the obect was found, define a new object list
			c.scope.listContainer.defineObjectList(name);
			return data;
		}

		else {
			// object list outside of an object, define object list in this scope
			int slot = scope.listContainer.defineObjectList(name);
			return data;
		}
	}

	// reference to an object list value
	public Object visit(ASTDereferenceListObject node, Object data) {
		String name = getTokenOfChild(node, 0);
		// check the object list exists
		int slot = scope.listContainer.findLocalSlotNumberObject(name);

		if (slot == -1) {
			throw new ExceptionSemantic("list " + name + " does not exist.");
		}

		// find the object at the specified index
		ClassInstance c = scope.listContainer.getListObj(slot, (int) doChild(node, 1).longValue());

		String varName = getTokenOfChild(node, 2);

		// if the command is to reference the entire object, pass the name
		if (varName.equalsIgnoreCase("CopyObject")) {
			return new ValueString(c.name);
		}

		Display.Reference reference;

		// if the command is for a variable inside the object, find that instead
		reference = c.scope.findReference(getTokenOfChild(node, 2));
		
		if(reference == null)
		{
			throw new ExceptionSemantic("Variable " + getTokenOfChild(node, 2) + " does not exist in " + c.name);
		}

		return reference.getValue();
	}

	// sort a normal list
	public Object visit(ASTListSort node, Object data) {
		String name = getTokenOfChild(node, 0);
		
		// check the list exists 
		int slot = scope.listContainer.findLocalSlotNumber(name);

		if (slot == -1) {
			throw new ExceptionSemantic("list " + name + " does not exist.");
		}

		// get the sort type 
		String sortType = getTokenOfChild(node, 1);
		
		if(!sortType.equalsIgnoreCase("asc") && !sortType.equalsIgnoreCase("des"))
		{
			throw new ExceptionSemantic("Sort needs asc or des command");
		}
		
		// sort the list
		scope.listContainer.sortList(slot, sortType);

		return null;
	}

	// sort an object list by a variable within the objects
	public Object visit(ASTListSortObj node, Object data) {
		String name = getTokenOfChild(node, 0);
		
		// find the object list
		int slot = scope.listContainer.findLocalSlotNumberObject(name);

		if (slot == -1) {
			throw new ExceptionSemantic("list " + name + " does not exist.");
		}

		
		String sortType = getTokenOfChild(node, 1);
		
		// check the sort type is correct
		if(!sortType.equalsIgnoreCase("asc") && !sortType.equalsIgnoreCase("des"))
		{
			throw new ExceptionSemantic("SortObj needs asc or des command");
		}
		
		String var = getTokenOfChild(node, 2);
		scope.listContainer.sortListObj(slot, var, sortType);

		return null;
	}

	// get a reference to a list in an object
	public Object visit(ASTObjectDereferenceList node, Object data) {
		String name = getTokenOfChild(node, 1);
		
		// find the object
		String classNameHere = getTokenOfChild(node, 0);
		ClassInstance c = classContainer.findClassInstance(classNameHere);
		
		if(c == null)
		{
			throw new ExceptionSemantic("Object instance " + classNameHere + " does not exist.");
		}
		Display.Reference reference = null;

		// find the list
		int slot = c.scope.listContainer.findLocalSlotNumber(getTokenOfChild(node, 1));

		// the list does not exist
		if (slot == -1) {
			throw new ExceptionSemantic("list " + name + " does not exist in object " + classNameHere);
		}

		// return the value from the list
		Object ob = c.scope.listContainer.getListValue(slot, (int) doChild(node, 2).longValue());

		if (ob == null) {
			throw new ExceptionSemantic("Index " + doChild(node, 0) + " for list " + name + " out of bounds.");
		}

		return ob;
	}

	// reference to an object list value existing within an object
	public Object visit(ASTObjectDereferenceListObj node, Object data) {
		String name = getTokenOfChild(node, 1);
		// find the obect
		String classNameHere = getTokenOfChild(node, 0);
		ClassInstance c = classContainer.findClassInstance(classNameHere);
		Display.Reference reference = null;

		if(c == null)
		{
			throw new ExceptionSemantic("Object instance " + classNameHere + " does not exist.");
		}
		
		// find the object list
		int slot = c.scope.listContainer.findLocalSlotNumberObject(name);

		if (slot == -1) {
			throw new ExceptionSemantic("list " + name +  " does not exist in object " + classNameHere);
		}

		// find the object from the object list by index
		ClassInstance innerClass = c.scope.listContainer.getListObj(slot, (int) doChild(node, 2).longValue());

		// find the reference to the variable
		reference = innerClass.scope.findReference(getTokenOfChild(node, 3));

		return reference.getValue();
	}

	// set a variable to a normal list at an index
	public Object visit(ASTSetList node, Object data) {
		String name = getTokenOfChild(node, 0);
		int slot = scope.listContainer.findLocalSlotNumber(name);

		// find the list
		if (slot == -1) {

			throw new ExceptionSemantic("list " + name + " does not exist.");

		}

		// set the value at specified index to the incoming value
		scope.listContainer.setListValue(slot, (int) doChild(node, 1).longValue(), doChild(node, 2));
		return null;
	}

	// set a value to a normal list within an object by index
	public Object visit(ASTObjectSetList node, Object data) {

		String nameClass = getTokenOfChild(node, 0);
		
		// check the object exists
		ClassInstance c = classContainer.findClassInstance(nameClass);

		if (c == null) {
			throw new ExceptionSemantic("Object instance " + nameClass + " does not exist.");
		}

		// check the list exists 
		String name = getTokenOfChild(node, 1);
		int slot = c.scope.listContainer.findLocalSlotNumber(name);

		if (slot == -1) {

			throw new ExceptionSemantic("list " + name + " does not exist in Object instance " + nameClass);

		}

		// get and set the value at the specified index
		c.scope.listContainer.setListValue(slot, (int) doChild(node, 2).longValue(), doChild(node, 3));
		return null;
	}

	// set a value or object to an object list by index
	public Object visit(ASTSetObjectList node, Object data) {

		// check the object list exits
		String name = getTokenOfChild(node, 0);
		int slot = scope.listContainer.findLocalSlotNumberObject(name);

		if (slot == -1) {

			throw new ExceptionSemantic("list " + name + " does not exist.");

		}

		// get the object existing at the index specified
		ClassInstance c = scope.listContainer.getListObj(slot, (int) doChild(node, 1).longValue());

		if (c == null) {
			throw new ExceptionSemantic("Object list " + name + " does not contain " + doChild(node, 1).longValue() + " elements");
		}
		String varName = getTokenOfChild(node, 2);

		// if this command is present then set the entire object to the incoming instance
		if (varName.equalsIgnoreCase("CopyObject")) {
			ClassInstance newClass;

			// get the object name this index will be assigned to
			String className = getTokenOfChild(node, 3);

			if (className == null) {
				className = doChild(node, 3).stringValue();
			}

			// find the object
			newClass = classContainer.findClassInstance(className);

			if (newClass == null) {

				throw new ExceptionSemantic("Object instance " + getTokenOfChild(node, 3) + " does not exist.");
			}
			
			// set the object at the specified index to the object specified
			scope.listContainer.setListValueObject(slot, (int) doChild(node, 1).longValue(), newClass);
			return data;
		}

		Display.Reference reference = c.scope.findReference(varName);

		// else a variable is being set
		if (reference == null) {
			throw new ExceptionSemantic("Variable " + varName + " does not exist in class " + c.name);
		}

		// set the value
		reference.setValue(doChild(node, 3));
		// c.scope.listContainer.setListValue(slot, (int)doChild(node, 2).longValue(),
		// doChild(node, 3));
		return null;
	}

	
	// set a object or variable to an object list existing within an object
	public Object visit(ASTObjectSetObjectList node, Object data) {
		// get the object name and list name
		String name = getTokenOfChild(node, 1);
		String nameClass = getTokenOfChild(node, 0);

		// check the object exists
		ClassInstance c = classContainer.findClassInstance(nameClass);
		if (c == null) {
			throw new ExceptionSemantic("Object " + nameClass + " does not exist.");
		}

		// check the list exists
		int slot = c.scope.listContainer.findLocalSlotNumberObject(name);
		if (slot == -1) {

			throw new ExceptionSemantic("Object list " + name + " does not exist.");

		}

		// check the references object from the list exists
		ClassInstance listClass = scope.listContainer.getListObj(slot, (int) doChild(node, 2).longValue());

		if (listClass == null) {
			throw new ExceptionSemantic("Object " + listClass + " not exist.");
		}
		String varName = getTokenOfChild(node, 3);

		// check if the entire object is being copied
		if (varName.equalsIgnoreCase("CopyObject")) {
			// find the object, check it exists and set it at the specified object list
			// index
			ClassInstance newClass;
			String className = getTokenOfChild(node, 4);

			if (className == null) {
				className = doChild(node, 4).stringValue();
			}

			// check the incoming object exists
			newClass = classContainer.findClassInstance(className);

			if (newClass == null) {

				throw new ExceptionSemantic("Object " + getTokenOfChild(node, 4) + " does not exist.");
			}
			scope.listContainer.setListValueObject(slot, (int) doChild(node, 2).longValue(), newClass);
			return data;
		}

		Display.Reference reference = c.scope.findReference(varName);

		if (reference == null) {
			throw new ExceptionSemantic("Variable " + varName + " does not exist in object " + c.name);
		}
		

		reference.setValue(doChild(node, 4));
		// c.scope.listContainer.setListValue(slot, (int)doChild(node, 2).longValue(),
		// doChild(node, 3));
		return null;
	}

	public Object visit(ASTRandom node, Object data) {
		// get the values
		Value v1 = doChild(node, 0);
		Value v2 = doChild(node, 1);
		Value v = null;

		// check to ensure the values are not strings
		if (v1.getName().equalsIgnoreCase("string") || v2.getName().equalsIgnoreCase("string")) {
			throw new ExceptionSemantic("Values in Random cannot be strings");
		}

		// check if the random is a double random
		if (node.tokenValue.equalsIgnoreCase("RANDOMD")) {
			double precision = 10D;
			double number = random.nextInt((int) ((v2.doubleValue() - v1.doubleValue()) * precision + 1))
					+ v1.doubleValue() * precision;
			number = number / precision;
			v = new ValueRational(number);
		}

		// else it is a normal random
		else {
			int rand = random.nextInt((int) doChild(node, 1).longValue() - (int) doChild(node, 0).longValue() + 1)
					+ (int) doChild(node, 0).longValue();
			v = new ValueInteger(rand);
		}
		return v;
	}

	public Object visit(ASTListAddNewObject node, Object data) {
		// check the list exists
		String nameList = getTokenOfChild(node, 0);
		int slot = scope.listContainer.findLocalSlotNumberObject(nameList);

		// throw if it does not exists
		if (slot == -1) {
			throw new ExceptionSemantic("list " + nameList + " does not exist.");
		}

		// create new object, calling it objectName + n
		String name;
		ClassType type = classContainer.findClassType(getTokenOfChild(node, 1));
		name = type.className.toLowerCase() + "" + classContainer.getNumberOfClassWithName(type.className);
		classContainer.defineClass(name, type);
		className = name;
		node.optimised = classContainer;

		// do the object constructor
		doChild(node, 2);

		// add object to the object list
		ClassInstance c = classContainer.findClassInstance(name);
		scope.listContainer.addToListObj(slot, c);
		return data;
	}

	public Object visit(ASTObjectListAddNewObject node, Object data) {
		// check object type exists
		String inClassName = getTokenOfChild(node, 0);
		ClassInstance mainClass = classContainer.findClassInstance(inClassName);

		// if null then throw
		if (mainClass == null) {
			throw new ExceptionSemantic("class " + inClassName + " does not exist.");
		}

		// find the object list
		String nameList = getTokenOfChild(node, 1);
		int slot = mainClass.scope.listContainer.findLocalSlotNumberObject(nameList);

		if (slot == -1) {
			throw new ExceptionSemantic("list " + nameList + " does not exist.");
		}

		// create a new object and give it a name of objectName + n
		String name;
		ClassType type = classContainer.findClassType(getTokenOfChild(node, 2));
		name = type.className.toLowerCase() + "" + classContainer.getNumberOfClassWithName(type.className);
		classContainer.defineClass(name, type);
		className = name;
		node.optimised = classContainer;

		// do the object constructor
		doChild(node, 3);

		// add the object to the object list
		ClassInstance c = classContainer.findClassInstance(name);
		mainClass.scope.listContainer.addToListObj(slot, c);
		return data;
	}

	public Object visit(ASTFileCreate node, Object data) {
		// parse the incoming arguments
		String fileName = getTokenOfChild(node, 0);
		String fileNameParse = fileName.replace("\"", "");
		boolean amend = doChild(node, 1).booleanValue();
		boolean newLine = doChild(node, 2).booleanValue();
		String seperator = getTokenOfChild(node, 3);
		String seperatorParse = seperator.replace("\"", "");

		// create a file instance
		File file = new File(fileNameParse);

		try {
			// if the file does not exists, create it
			if (!file.exists()) {
				file.createNewFile();
			}

			// Write Content
			FileWriter writer;
			writer = new FileWriter(file, amend);

			// for each argument, add it to the file
			for (int i = 4; i < node.jjtGetNumChildren(); i++) {
				// find the argument or object
				String inArg = (doChild(node, i).toString());
				ClassInstance c = classContainer.findClassInstance(inArg);

				// if an object is the argument, copy each var variables into the file
				if (c != null) {
					for (int j = 0; j < c.classType.names.size(); j++) {
						Display.Reference reference = c.scope.findReference(c.classType.getNames(j));
						writer.write(reference.getValue() + seperatorParse);
					}
				}

				// else write the normal variable to the file
				else {
					writer.write(doChild(node, i).toString() + seperatorParse);
				}

				// if the new line option is triggered, create a new line after each call of
				// filecreate
				if (newLine) {
					writer.write(System.getProperty("line.separator"));
				}
			}

			writer.close();
		}

		catch (IOException e) {
			System.out.println(e.toString());
		}
		return null;
	}

	public Object visit(ASTFileRead node, Object data) {

		// parse the incoming arguments
		String fileName = getTokenOfChild(node, 0);
		String fileNameParse = fileName.replace("\"", "");
		int readAmount = (int) doChild(node, 1).longValue();
		String seperator = getTokenOfChild(node, 2);
		String seperatorParse = seperator.replace("\"", "");

		File file = new File(fileNameParse);

		try {
			// check the file exists
			if (!file.exists()) {
				throw new ExceptionSemantic("File " + fileNameParse + " does not exist");
			}

			// create buffered and file reader,read file, add findings to a list
			FileReader reader;
			reader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(reader);
			String lines;
			ArrayList<String> fileParts = new ArrayList<String>();

			while ((lines = bufferedReader.readLine()) != null) {
				String[] parts = lines.split(seperatorParse);

				// checks for the correct separator in regards to the file
				if (parts.length == 1) {
					bufferedReader.close();
					throw new ExceptionSemantic("Seperator " + seperator + " was not found in the file");
				}
				for (int i = 0; i < parts.length; i++) {
					fileParts.add(parts[i]);

				}
			}

			// close the readers
			bufferedReader.close();
			reader.close();

			// check the readAmount to see if the list contains this amount of data
			if (readAmount > fileParts.size()) {
				System.out.println("File " + fileNameParse + " does not contain " + readAmount + " values");
				return null;
			}

			// save the read variables into the selected object
			for (int i = 3; i < node.jjtGetNumChildren(); i++) {
				String inArg = (doChild(node, i).toString());
				ClassInstance c = classContainer.findClassInstance(inArg);

				// check to see if the object exists
				if (c != null) {
					for (int j = 0; j < c.classType.names.size(); j++) {
						if (readAmount + j > fileParts.size()) {
							System.out.println("No more values in file");
							return data;
						}
						Display.Reference reference = c.scope.findReference(c.classType.getNames(j));
						reference.setValue(new ValueString(fileParts.get(readAmount + j)));
					}
				}

			}
		}

		catch (IOException e) {
			throw new ExceptionSemantic("Error parsing the file");
		}
		return null;
	}

}
