package objScript.interpreter;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import objScript.values.Value;

public class ArrayContainer {

	private Vector<Value[]> arrays;
	private HashMap<String, Integer> arrayNames = new HashMap<String, Integer>();

	ArrayContainer() {
		arrays = new Vector<Value[]>();
	}

	// define an array and return the slot
	int defineArray(String name) {
		Integer slot = arrayNames.get(name);
		if (slot != null)
			return slot.intValue();
		int slotNumber = arrayNames.size();
		arrayNames.put(name, Integer.valueOf(slotNumber));
		return slotNumber;
	}

	// set the hashmap
	void setSlots(HashMap<String, Integer> inSlots) {
		arrayNames = inSlots;
	}

	// copy the hashmap into another
	void copySlots(HashMap<String, Integer> inSlots) {
		for (Map.Entry<String, Integer> entry : arrayNames.entrySet()) {
			inSlots.put(entry.getKey(), entry.getValue());
		}
	}

	//copy the array vector
	void copyVector(Vector<Value[]> inSlots) {
		inSlots.addAll(arrays);
	}

	// set the array vector
	void setVector(Vector<Value[]> inSlots) {
		arrays.addAll(inSlots);
	}

	
	void setSlot(int n, Value[] v) {
		if (n >= arrays.size())
			arrays.setSize(n + 1);
		arrays.set(n, v);
	}

	int findLocalSlotNumber(String name) {
		Integer slot = arrayNames.get(name);
		if (slot == null)
			return -1;
		return slot.intValue();
	}

	/** Get a variable or parameter value given a slot number. */
	Value[] getArray(int slotNumber) {
		Value[] v = arrays.get(slotNumber);

		if (v == null) {
			return null;
		}
		return v;
	}
	

	//get an array value by index
	Value getArrayValue(int slotNumber, int index) {
		Value[] v = arrays.get(slotNumber);

		if (v == null) {

			return null;
		}

		if (index > v.length) {

			return null;
		}
		Value val = v[index];

		return val;
	}

	//set an array value by index
	int setArrayValue(int slotNumber, int index, Value value) {
		Value[] v = arrays.get(slotNumber);

		if (v == null) {

			return -1;
		}

		if (index > v.length) {

			return -1;
		}

		v[index] = value;
		return 0;

	}
}
