package objScript.interpreter;

import java.util.ArrayList;
import java.util.HashMap;

import objScript.values.Value;

public class ClassType {

	public String className;
	public Display scope = new Display();

	ArrayList<String> names;

	public ClassType(String name) {
		className = name;
		names = new ArrayList<String>();

	}

	// add a variable name
	void addNames(String inName) {
		names.add(inName);
	}

	// get a variable name by index
	String getNames(int index) {
		if (index >= names.size()) {
			return null;
		}
		return names.get(index);
	}
}
