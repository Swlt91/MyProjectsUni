package objScript.interpreter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import objScript.values.Value;

public class ListContainer {
	Vector<ArrayList<Value>> lists;
	Vector<ArrayList<ClassInstance>> classLists;
	private HashMap<String, Integer> listNames = new HashMap<String, Integer>();
	private HashMap<String, Integer> listNamesObj = new HashMap<String, Integer>();
	
	ListContainer()
	{
		lists = new Vector<ArrayList<Value>>();
		classLists = new Vector<ArrayList<ClassInstance>>();
	}
	/** Define a variable.  Return its slot number. */
	int defineList(String name) {
		Integer slot = listNames.get(name);
		if (slot != null)
			return slot.intValue();
		int slotNumber = listNames.size();
		listNames.put(name, Integer.valueOf(slotNumber));
		setSlot(slotNumber, new ArrayList<Value>());
		return slotNumber;
	}	
	
	
	// create an object list
	int defineObjectList(String name) {
		Integer slot = listNamesObj.get(name);
		if (slot != null) {
			return slot.intValue();}
		int slotNumber = listNamesObj.size();
		listNamesObj.put(name, Integer.valueOf(slotNumber));
		setSlotObj(slotNumber, new ArrayList<ClassInstance>());
		return slotNumber;
	}	
	
	
	// set the list slots
	void setSlots(HashMap<String, Integer> inSlots)
	{
		listNames = inSlots;
	}
	
	
	// set the object list slots
	void setObjSlots(HashMap<String, Integer> inSlots)
	{
		listNamesObj= inSlots;
	}
	
	// copy the object list slots
	void copySlotsObj(HashMap<String, Integer> inSlots)
	{
		 for (Map.Entry<String, Integer> entry : listNamesObj.entrySet())
		    {
		        inSlots.put(entry.getKey(), entry.getValue());
		    }		
	}
	
	// copy the list slots
	void copySlots(HashMap<String, Integer> inSlots)
	{
		 for (Map.Entry<String, Integer> entry : listNames.entrySet())
		    {
		        inSlots.put(entry.getKey(), entry.getValue());
		           
		    }		
	}
	
	// copy object list vector
	void copyVectorObj(Vector<ArrayList<ClassInstance>> inSlots)
	{
		inSlots.addAll(classLists);
	}
	
	// set the object list vector
	void setVectorObj(Vector<ArrayList<ClassInstance>> inSlots)
	{
		classLists.addAll(inSlots);
	}
	
	// copy list vector
	void copyVector(Vector<ArrayList<Value>> inSlots)
	{
		inSlots.addAll(lists);
	}
	
	// set the list vector
	void setVector(Vector<ArrayList<Value>> inSlots)
	{
		lists.addAll(inSlots);
	}
	
	// set list slot
	void setSlot(int n,ArrayList<Value> o) {
		if (n >= lists.size())
			lists.setSize(n + 1);
		lists.set(n, o);
	}
	
	// set object list slot
	void setSlotObj(int n,ArrayList<ClassInstance> o) {
		if (n >= classLists.size())
			classLists.setSize(n + 1);
		classLists.set(n, o);
	}
	
	// find number of slots from object list
	int findLocalSlotNumberObject(String name)
	{
		Integer slot = listNamesObj.get(name);
		if (slot == null)
		{	
			return -1;
			
		}
		return slot.intValue();
	}
	
	// find the number of slots in a list
	int findLocalSlotNumber(String name) {
		Integer slot = listNames.get(name);
		if (slot == null)
		{	
			return -1;
			
		}
		return slot.intValue();
	}
	
	// get the list at the specified slot
	ArrayList<Value> getArray(int slotNumber) {
		ArrayList<Value> v = lists.get(slotNumber);
		
		if(v == null)
		{
			return null;
		}
		return v;
	}
	
	// get the list value by slot and index
	Value getListValue(int slotNumber, int index) {
		
		ArrayList<Value> o=  lists.get(slotNumber);
		
		if(o == null)
		{
			
			return null;
		}
		
		
		if(index > o.size())
		{
			
			return null;
		}
		Value obj = o.get(index);

		return obj;
	}
	
	// get the object at the specified index and slot
	ClassInstance getListObj(int slotNumber, int index) {
		
		ArrayList<ClassInstance> o=  classLists.get(slotNumber);

		if(o == null)
		{
			
			return null;
		}
		
		
		if(index > o.size())
		{
			
			return null;
		}
		ClassInstance c = o.get(index);

		return c;
	}
	
	// add object to an object list
	int addToListObj(int slotNumber, ClassInstance c)
	{

		ArrayList<ClassInstance> o=  classLists.get(slotNumber);
	
		
		if(o == null)
		{
			
			return -1;
		}
		
		o.add(c);
		return 0;
	}
	
	// add value to a list
	int addToList(int slotNumber, Value obj)
	{

		ArrayList<Value> o =  lists.get(slotNumber);
		if(o == null)
		{
			
			return -1;
		}
		
		o.add(obj);
		return 0;
	}
	
	// set a list value by index and slot
	int setListValue(int slotNumber, int index, Value obj)
	{
		ArrayList<Value> o =  lists.get(slotNumber);
		
		if(o == null)
		{
			
			return -1;
		}
		
		if(index > o.size())
		{
			
			return -1;
		}
		
		o.set(index, obj);
		
		return 0;
	}
	
	// set an object list object by the specified slot and index
	int setListValueObject(int slotNumber, int index, ClassInstance c)
	{
		ArrayList<ClassInstance> cList =  classLists.get(slotNumber);
		
		if(cList == null)
		{
			
			return -1;
		}
		
		if(index > cList.size())
		{
			
			return -1;
		}
		
		cList.set(index, c);
		
		return 0;
	}
	
	// get the size of a list
	int getSize(int slotNumber)
	{
		ArrayList<Value> o =  lists.get(slotNumber);
		if(o == null)
		{
			
			return -1;
		}
		
		return o.size();
	}
	
	// get the size of an object list
	int getSizeObject(int slotNumber)
	{
		ArrayList<ClassInstance> c =  classLists.get(slotNumber);
		if(c == null)
		{
			
			return -1;
		}
		
		return c.size();
	}
	
	// remove from a list by slot and index
	int removeFromList(int slotNumber, int index)
	{
		ArrayList<Value> o =  lists.get(slotNumber);
		if(o == null)
		{
			
			return -1;
		}
		
		if(index > o.size())
		{
			
			return -1;
		}
		
		o.remove(index);
		
		return 0;
		
	}
		
	// remove from an object list by slot nubmer and index
	int removeFromListObj(int slotNumber, int index)
	{
		ArrayList<ClassInstance> cList =  classLists.get(slotNumber);
		
		if(cList == null)
		{
			
			return -1;
		}
		
		if(index > cList.size())
		{
			
			return -1;
		}
		
		cList.remove(index);
		
		return 0;
		
	}
	
	// sort list by slot number and sort type
	void sortList(int slotNumber, String type)
	{
		ArrayList<Value> o =  lists.get(slotNumber);

		// ensure the list has only one type
		if(o.get(0).getName() == "integer")
		{
			
			Collections.sort(o, new Comparator<Value>() {
			    @Override
			    public int compare(Value o1, Value o2) {
			        return Long.compare(o1.longValue(), o2.longValue());
			    }
			});
		}
		
		// else sort by string
		else
		{
			Collections.sort(o, new Comparator<Value>() {
			    @Override
			    public int compare(Value s1, Value s2) {
			        return s1.stringValue().compareToIgnoreCase(s2.stringValue());
			    }
			});
		}
		
		// if descending was selected, reverse the list
		if(type.equalsIgnoreCase("des"))
		{
			Collections.reverse(o);
		}
	}
	
	
	// sort object list by slot number, variable and type
	void sortListObj(int slotNumber, String var, String type)
	{
		ArrayList<ClassInstance> o =  classLists.get(slotNumber);

		// check the list contains integers
		if(o.get(0).scope.findReference(var).getValue().getName() == "integer")
		{
			
			// sort and find the variables in each object
			
			Collections.sort(o, new Comparator<ClassInstance>() {
			    @Override
			    public int compare(ClassInstance o1, ClassInstance o2) {
			    	Display.Reference reference = o1.scope.findReference(var);
			    	if(reference == null)
			    	{
			    		throw new ExceptionSemantic("variable " + var + " does not exist in the object list.");
			    	}
			    	
			    	Display.Reference reference2 = o2.scope.findReference(var);
			    	
			        return Long.compare(reference.getValue().longValue(), reference2.getValue().longValue());
			    }
			});
		}
		
		// else sort by string
		else
		{
			Collections.sort(o, new Comparator<ClassInstance>() {
			    @Override
			    public int compare(ClassInstance o1, ClassInstance o2) {
			    	Display.Reference reference = o1.scope.findReference(var);
			    	if(reference == null)
			    	{
			    		throw new ExceptionSemantic("variable " + var + " does not exist in the object list.");
			    	}
			    	
			    	Display.Reference reference2 = o2.scope.findReference(var);
			    	 return reference.getValue().stringValue().compareToIgnoreCase(reference2.getValue().stringValue());
			    }
			});
		}
		
		// reverse the list if descending command selected
		if(type.equalsIgnoreCase("des"))
		{
			Collections.reverse(o);
		}
	}
	
}
