package objScript.interpreter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

import objScript.values.Value;

public class ClassInstance {

	public String name;
	public ClassType classType;
	Display scope = new Display();

	public ClassInstance(String inName, ClassType c) throws CloneNotSupportedException {
		name = inName;
		classType = c;
		// scope = classType.scope;
		GetData();
	}

	void GetData() {
		int levelCount = 0;

		// copy values
		Vector<Value> values = new Vector<Value>();
		HashMap<String, Integer> inSlots = new HashMap<String, Integer>();
		classType.scope.copyVector(levelCount, values);
		scope.setVector(levelCount, values);
		classType.scope.copyFunctionDefSlots(levelCount, inSlots);
		scope.setFunctionDefHash(levelCount, inSlots);

		// copy arrays
		Vector<Value[]> arrayValues = new Vector<Value[]>();
		HashMap<String, Integer> arraySlots = new HashMap<String, Integer>();
		classType.scope.arrayContainer.copySlots(arraySlots);
		scope.arrayContainer.setSlots(arraySlots);
		classType.scope.arrayContainer.copyVector(arrayValues);
		scope.arrayContainer.setVector(arrayValues);

		// copy lists
		Vector<ArrayList<Value>> lists = new Vector<ArrayList<Value>>();
		HashMap<String, Integer> listSlots = new HashMap<String, Integer>();
		classType.scope.listContainer.copySlots(listSlots);
		scope.listContainer.setSlots(listSlots);
		classType.scope.listContainer.copyVector(lists);
		scope.listContainer.setVector(lists);

		// copy functions
		HashMap<String, FunctionDefinition> inFunctions = new HashMap<String, FunctionDefinition>();
		classType.scope.copyFunctionDefFunctions(levelCount, inFunctions);
		scope.setFunctionDefFunctions(levelCount, inFunctions);
		scope.setArgumentCount(levelCount, scope.getArgumentCount(levelCount));
		levelCount++;

		// copy objLists
		Vector<ArrayList<ClassInstance>> classLists = new Vector<ArrayList<ClassInstance>>();
		HashMap<String, Integer> classListNames = new HashMap<String, Integer>();
		classType.scope.listContainer.copySlotsObj(classListNames);
		scope.listContainer.setObjSlots(classListNames);
		classType.scope.listContainer.copyVectorObj(classLists);
		scope.listContainer.setVectorObj(classLists);
	}
}
